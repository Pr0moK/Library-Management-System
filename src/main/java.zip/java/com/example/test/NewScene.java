package com.example.test;

import com.example.test.Controller.AcceptBookReturnViewController;
import com.example.test.utils.OnBookReturnListener;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class NewScene {
    private int width;
    private int height;
    private String stageTitle;
    private static final int d_width = 800;
    private static final int d_height = 600;

    public NewScene(String fxml) throws IOException {
        this.width = d_width;
        this.height = d_height;
    }

    public NewScene(String fxml, int width, int height) throws IOException {
        this.width = width;
        this.height = height;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
        Scene scene = new Scene(fxmlLoader.load(), width, height);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        stage.setTitle(stageTitle);
    }

        public NewScene(String fxml, int width, int height, OnBookReturnListener listener) throws IOException {
        this.width = width;
        this.height = height;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
        Scene scene = new Scene(fxmlLoader.load(), width, height);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

        AcceptBookReturnViewController acceptController = fxmlLoader.getController();
        acceptController.setOnBookReturnListener(listener);
    }
}
