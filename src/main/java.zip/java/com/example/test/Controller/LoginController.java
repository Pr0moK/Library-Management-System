package com.example.test.Controller;

import com.example.test.DatabaseAction;
import com.example.test.SwitchScene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;


public class LoginController {
    @FXML
    private Label LoginError;
    @FXML
    private TextField username;
    @FXML
    private TextField password;



    @FXML
    protected void onFinishLoginButtonClick(ActionEvent event) throws IOException {
        String user;
        String userPassword;

        user = username.getText();
        userPassword = password.getText();


        System.out.println("Login " + user + " " + userPassword);
        DatabaseAction databaseAction = new DatabaseAction();


        boolean result_login = databaseAction.CheckIfUserExists(user,userPassword);

        if(result_login){
            System.out.println("Login OK");
            SwitchScene scena = new SwitchScene("MenuView.fxml",event,800,539);
        } else {
            LoginError.setText("Błąd Logowania");
            System.out.println("Login Failed");
        }


    }

    @FXML
    protected void BackButtonClick(ActionEvent event) throws IOException {
        SwitchScene scena = new SwitchScene("MainView.fxml",event,400,400);
    }

}
