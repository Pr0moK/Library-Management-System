package com.example.test.Controller;

import com.example.test.BookManagement;
import com.example.test.Books;
import com.example.test.DeleteScene;
import com.example.test.LoadDataToList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class BookListController {

    @FXML
    private Label BookError;

    @FXML
    private TextField bookAmount;

    @FXML
    private TextField bookAuthor;

    @FXML
    private TextField bookTitle;

    @FXML
    private TableView<Books> booksTable;

    @FXML
    private TableColumn<Books, Integer> colAmou;

    @FXML
    private TableColumn<Books, String> colAuth;

    @FXML
    private TableColumn<Books, String> colTitle;

    @FXML
    public void initialize() throws IOException {
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colAuth.setCellValueFactory(new PropertyValueFactory<>("author"));
        colAmou.setCellValueFactory(new PropertyValueFactory<>("amount"));
        LoadbookData();
    }

    public void LoadbookData() throws IOException {
        LoadDataToList loader = new LoadDataToList();
        try {
            ObservableList<Books> booksList = loader.loadBooksData();
            booksTable.setItems(booksList);
        } catch (IOException e) {
            System.err.println("Błąd podczas ładowania danych użytkowników: " + e.getMessage());
        }
    }

    @FXML
    protected void AddBook() throws IOException {
        if(bookAuthor.getText().isEmpty() || bookTitle.getText().isEmpty() || bookAmount.getText().isEmpty()){
            BookError.setText("Uzupełnij wszystkie pola!");
        }else {
            BookError.setText("");
            try {
                BookManagement bookManagement = new BookManagement();

                bookManagement.AddBook(bookTitle.getText(),bookAuthor.getText(), Integer.parseInt(bookAmount.getText()));
                BookError.setText("Pomyślnie dodano książkę.");
                LoadbookData();
            } catch (NumberFormatException e) {
                System.out.println("Amount nie jest cyfra.");
                BookError.setText("Liczba musi być cyfrą!");
            }
        }
    }

    @FXML
    protected void BookListRemoveWindow(ActionEvent event) throws IOException {
        DeleteScene booklistdelete = new DeleteScene(event);
    }

    @FXML
    protected void EditBook() throws IOException {
        if (bookAuthor.getText().isEmpty() || bookTitle.getText().isEmpty() || bookAmount.getText().isEmpty()) {
            BookError.setText("Uzupełnij wszystkie pola!");
        } else {
            BookError.setText("");
            try {

                BookManagement bookManagement = new BookManagement();

                if (bookManagement.EditBookAmount(bookTitle.getText(), bookAuthor.getText(), Integer.parseInt(bookAmount.getText()))) {
                    LoadbookData();
                    System.out.println("Pomyślnie edytowano liczbę książek.");
                    BookError.setText("Pomyślnie edytowano liczbę książek.");
                } else {
                    System.out.println("Nie istnieje taka książka.");
                    BookError.setText("NIe znaleziono książki");
                }
            } catch (NumberFormatException e) {
                System.out.println("Amount nie jest cyfra.");
                BookError.setText("Liczba nie jest cyfrą!");
            }

        }
    }

    @FXML
    protected void RemoveBook() throws IOException {
        if (bookAuthor.getText().isEmpty() || bookTitle.getText().isEmpty() || bookAmount.getText().isEmpty()) {
            BookError.setText("Uzupełnij wszystkie pola!");
        } else {
            BookError.setText("");
            try {


                BookManagement bookManagement = new BookManagement();

                if (bookManagement.RemoveBook(bookTitle.getText(), bookAuthor.getText())) {
                    BookError.setText("Pomyślnie usunięto książkę.");
                    LoadbookData();
                } else {
                    BookError.setText("Nie znaleziono książki!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Amount nie jest cyfra.");
                BookError.setText("Liczba nie jest cyfrą!");
            }
        }
    }

    @FXML
    protected void GetdataRow() {
        int index = booksTable.getSelectionModel().getSelectedIndex();

        if(index <= -1){
            return;
        }
        bookTitle.setText(String.valueOf(colTitle.getCellData(index)));
        bookAuthor.setText(String.valueOf(colAuth.getCellData(index)));
        bookAmount.setText(String.valueOf(colAmou.getCellData(index)));
    }
}
