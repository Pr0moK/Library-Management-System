package com.example.test.Controller;

import com.example.test.DatabaseAction;
import com.example.test.SwitchScene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;


public class RegisterController {
    @FXML
    private Label ErrorRegister;
    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private TextField fname;
    @FXML
    private TextField surname;

    @FXML
    protected void onFinishReg() throws IOException{
        String name;
        String LastName;
        String AccountPassword;
        String FirstName;

        name = username.getText();
        LastName = surname.getText();
        AccountPassword = password.getText();
        FirstName = fname.getText();


        System.out.printf("Imie %s Nazwisko %s Uzytkownik %s Hasło %s%n", FirstName, LastName, name, AccountPassword);

        if(name.isEmpty() || AccountPassword.isEmpty() || FirstName.isEmpty() || LastName.isEmpty()){
            ErrorRegister.setText("Uzupełnij wszystkie pola!");
        } else {
            DatabaseAction databaseAction = new DatabaseAction();

            boolean UserInDatabase = databaseAction.addUser(FirstName, LastName, name, AccountPassword);

            if (!UserInDatabase) {
                ErrorRegister.setText("Nazwa " + name + " jest zajęta");
            } else {
                ErrorRegister.setText("Zarejestrowano!");
            }
        }
    }

    @FXML
    protected void BackButtonClick(ActionEvent event) throws IOException {
        SwitchScene scena = new SwitchScene("MainView.fxml",event,400,400);
    }
}