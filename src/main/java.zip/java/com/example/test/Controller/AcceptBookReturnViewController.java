package com.example.test.Controller;

import com.example.test.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import com.example.test.utils.OnBookReturnListener;



import java.io.IOException;

public class AcceptBookReturnViewController {

    @FXML
    private Button AcceptReturnButton;

    @FXML
    private Button DeclineReturnButton;

    @FXML
    private Label fee;

    @FXML
    private Label username;

    private OnBookReturnListener bookReturnListener;

    public void setOnBookReturnListener(OnBookReturnListener listener) {
        this.bookReturnListener = listener;
    }


    @FXML
    public void initialize() {
        username.setText(ChoosedUser.getInstance().getUserLogin());
        fee.setText(ChoosedIssuedBook.getInstance().getUserFee() + "zł ");
    }

    @FXML
    public void DeclineReturnButton(ActionEvent event) {
        DeleteScene scene = new DeleteScene(event);
    }

    @FXML
    public void AcceptReturnButton(ActionEvent event) throws IOException {
        FeeManagement fee = new FeeManagement();
        System.out.println(ChoosedIssuedBook.getInstance().getIssuedBookId());
        if (fee.UpdateFee(ChoosedIssuedBook.getInstance().getIssuedBookId())) {
            BookManagement bookManagement = new BookManagement();
            bookManagement.ReturnBook(ChoosedIssuedBook.getInstance().getIssuedBookId());

            if (bookReturnListener != null) {
                bookReturnListener.onBookReturned();
                DeleteScene scene1 = new DeleteScene(event);
            } else {
                System.out.println("You have declined the book");
            }
        }
    }
}
