package com.example.test.Controller;

import com.example.test.BookManagement;
import com.example.test.DatabaseAction;
import com.example.test.NewScene;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.IOException;


public class MenuController {

    @FXML
    private Label TotalBooks;
    @FXML
    private Label TotalIssuedBooks;
    @FXML
    private Label TotalUsers;


    @FXML
    public void initialize() throws IOException {
        DatabaseAction base = new DatabaseAction();
        BookManagement bm = new BookManagement();
        TotalBooks.setText(String.valueOf(bm.CountBooks()));
        TotalIssuedBooks.setText(String.valueOf(bm.CountIssuedBooks()));
        TotalUsers.setText(String.valueOf(base.CountUsers()));
    }

    @FXML
    protected void BookListButtonClick() throws IOException {
        NewScene booklistscene = new NewScene("BooklistView.fxml",800,800);
    }
    @FXML
    protected void UserListButtonClick() throws IOException {
        NewScene userlistscene = new NewScene("UsersView.fxml",800,800);

    }
    @FXML
    protected void LendBookWindow() throws IOException {
        NewScene lendbookwindow = new NewScene("LendbookView.fxml",800,800);
    }
    @FXML
    protected void ReturnbookWindow() throws IOException{
        NewScene returnbookwindow = new NewScene("ReturnbookView.fxml",800,800);
    }
}