package com.example.test.Controller;

import com.example.test.SwitchScene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;


public class MainController {

    @FXML
    protected void onRegisterButtonClick(ActionEvent event) throws IOException {
        SwitchScene scena = new SwitchScene("RegisterView.fxml", event, 400, 400);

    }

    @FXML
    protected void LoginTestButtonClick(ActionEvent event) throws IOException {
        SwitchScene scena = new SwitchScene("LoginView.fxml", event, 400, 400);
    }

}