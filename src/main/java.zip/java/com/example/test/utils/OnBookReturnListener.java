package com.example.test.utils;

public interface OnBookReturnListener {
    void onBookReturned();
}
