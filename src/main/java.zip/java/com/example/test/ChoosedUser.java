package com.example.test;

public class ChoosedUser {

    private static final ChoosedUser instance = new ChoosedUser();

    private String firstName;
    private String lastName;
    private String login;

    private ChoosedUser() {}


    public static ChoosedUser getInstance() {
        return instance;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getUserLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }

}
