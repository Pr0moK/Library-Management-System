package com.example.test;

public class ChoosedIssuedBook {

    private static final ChoosedIssuedBook instance = new ChoosedIssuedBook();

    private int issuedBookId;
    private Double fee;


    private ChoosedIssuedBook() {}


    public static ChoosedIssuedBook getInstance() {
        return instance;
    }

    public void setIssuedBookId(int issuedBookId) {this.issuedBookId = issuedBookId;}
    public int getIssuedBookId() {return issuedBookId;}
    public void setUserFee(Double fee) {
        this.fee = fee;
    }
    public Double getUserFee(){
        return fee;
    }
}
